package com.mto.madetoorder.backend.model;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import java.time.Instant;

@Data
@Document(collection = "users")
public class User {

    @Id
    private String id;
    private String phoneNumber;
    private String email;
    private UserRole role;
    private boolean isActive;
    private Instant createdAt;
    private Instant updatedAt;
    private Instant lastLoginAt;
    private String otpCode;
    private Instant otpExpiresAt;
    private boolean otpVerified;

    public enum UserRole {
        CUSTOMER, KITCHEN, ADMIN
    }
}

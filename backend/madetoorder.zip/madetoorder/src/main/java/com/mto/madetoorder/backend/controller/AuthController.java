package com.mto.madetoorder.backend.controller;

import com.mto.madetoorder.backend.model.User;
import com.mto.madetoorder.backend.repository.UserRepository;
import com.mto.madetoorder.backend.security.JwtUtil;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.Random;

@RestController
@RequestMapping("/api/v1/auth")
public class AuthController {

    private final UserRepository userRepository;
    private final JwtUtil jwtUtil;
    private final Random random = new Random();

    public AuthController(UserRepository userRepository, JwtUtil jwtUtil) {
        this.userRepository = userRepository;
        this.jwtUtil = jwtUtil;
    }

    @PostMapping("/otp/send")
    public ResponseEntity<?> sendOtp(@RequestBody Map<String, String> request) {
        String phoneNumber = request.get("phoneNumber");
        String purpose = request.getOrDefault("purpose", "LOGIN");

        String otp = String.format("%06d", random.nextInt(999999));
        System.out.println("OTP for " + phoneNumber + ": " + otp);

        Optional<User> existingUser = userRepository.findByPhoneNumber(phoneNumber);

        if (existingUser.isPresent()) {
            User user = existingUser.get();
            user.setOtpCode(otp);
            user.setOtpExpiresAt(Instant.now().plus(5, ChronoUnit.MINUTES));
            user.setOtpVerified(false);
            userRepository.save(user);
        } else {
            // Create user for both LOGIN and REGISTRATION if not exists
            User newUser = new User();
            newUser.setPhoneNumber(phoneNumber);
            newUser.setRole(User.UserRole.CUSTOMER);
            newUser.setActive(true);
            newUser.setCreatedAt(Instant.now());
            newUser.setOtpCode(otp);
            newUser.setOtpExpiresAt(Instant.now().plus(5, ChronoUnit.MINUTES));
            newUser.setOtpVerified(false);
            userRepository.save(newUser);
        }

        Map<String, Object> response = new HashMap<>();
        response.put("success", true);
        response.put("message", "OTP sent successfully");
        response.put("expiresIn", 300);

        return ResponseEntity.ok(response);
    }

    @PostMapping("/otp/verify")
    public ResponseEntity<?> verifyOtp(@RequestBody Map<String, String> request) {
        String phoneNumber = request.get("phoneNumber");
        String otp = request.get("otp");

        Optional<User> userOpt = userRepository.findByPhoneNumber(phoneNumber);

        if (userOpt.isEmpty()) {
            return errorResponse("USER_NOT_FOUND", "User not found");
        }

        User user = userOpt.get();

        if (user.getOtpCode() == null || !user.getOtpCode().equals(otp)) {
            return errorResponse("INVALID_OTP", "Invalid OTP");
        }

        if (user.getOtpExpiresAt().isBefore(Instant.now())) {
            return errorResponse("OTP_EXPIRED", "OTP has expired");
        }

        user.setOtpVerified(true);
        user.setLastLoginAt(Instant.now());
        userRepository.save(user);

        String token = jwtUtil.generateToken(user.getId(), user.getPhoneNumber(), user.getRole().name());

        Map<String, Object> response = new HashMap<>();
        response.put("success", true);
        Map<String, Object> data = new HashMap<>();
        data.put("token", token);
        data.put("expiresIn", 86400);
        Map<String, Object> userData = new HashMap<>();
        userData.put("id", user.getId());
        userData.put("phoneNumber", user.getPhoneNumber());
        userData.put("role", user.getRole().name());
        userData.put("isProfileComplete", user.getEmail() != null && !user.getEmail().isEmpty());
        data.put("user", userData);
        response.put("data", data);

        return ResponseEntity.ok(response);
    }

    private ResponseEntity<?> errorResponse(String code, String message) {
        Map<String, Object> error = new HashMap<>();
        error.put("success", false);
        Map<String, Object> errorData = new HashMap<>();
        errorData.put("code", code);
        errorData.put("message", message);
        error.put("error", errorData);
        return ResponseEntity.badRequest().body(error);
    }
}

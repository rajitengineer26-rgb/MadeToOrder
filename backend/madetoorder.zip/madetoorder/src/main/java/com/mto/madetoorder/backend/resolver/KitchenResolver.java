package com.mto.madetoorder.backend.resolver;

import com.mto.madetoorder.backend.model.Kitchen;
import com.mto.madetoorder.backend.repository.KitchenRepository;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.graphql.data.method.annotation.SchemaMapping;
import org.springframework.stereotype.Controller;
import java.util.List;

@Controller
public class KitchenResolver {
    private final KitchenRepository kitchenRepository;
    private final MongoTemplate mongoTemplate;
    public KitchenResolver(KitchenRepository kitchenRepository, MongoTemplate mongoTemplate) {
        this.kitchenRepository = kitchenRepository;
        this.mongoTemplate = mongoTemplate;
    }
    @QueryMapping
    public List<Kitchen> kitchens() {
        List<Kitchen> list = kitchenRepository.findAll();
        System.out.println(" kitchens() called, found: " + list.size());
        System.out.println(" DB: " + mongoTemplate.getDb().getName());

        return list;
    }
    @QueryMapping
    public Kitchen kitchen(@Argument String id) {
        return kitchenRepository.findById(id).orElse(null);
    }
    // Flatten nested fields
    @SchemaMapping(typeName = "Kitchen", field = "name")
    public String name(Kitchen kitchen) {
        return kitchen.getKitchenName();
    }
    @SchemaMapping(typeName = "Kitchen", field = "area")
    public String area(Kitchen kitchen) {
        return kitchen.getAddress() != null ? kitchen.getAddress().getArea() : null;
    }
    @SchemaMapping(typeName = "Kitchen", field = "city")
    public String city(Kitchen kitchen) {
        return kitchen.getAddress() != null ? kitchen.getAddress().getCity() : null;
    }

    @SchemaMapping(typeName = "Kitchen", field = "type")
    public String type(Kitchen kitchen) {
        return kitchen.getType();  // Returns "NON_VEGETARIAN" as String
    }

    @SchemaMapping(typeName = "Kitchen", field = "state")
    public String state(Kitchen kitchen) {
        return kitchen.getAddress() != null ? kitchen.getAddress().getState() : null;
    }

    @SchemaMapping(typeName = "Kitchen", field = "pincode")
    public String pincode(Kitchen kitchen) {
        return kitchen.getAddress() != null ? kitchen.getAddress().getPincode() : null;
    }

}


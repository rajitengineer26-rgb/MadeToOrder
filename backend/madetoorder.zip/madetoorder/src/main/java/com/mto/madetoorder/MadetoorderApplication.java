package com.mto.madetoorder;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MadetoorderApplication {

    public static void main(String[] args) {
        SpringApplication.run(MadetoorderApplication.class, args);
    }

}

package com.mto.madetoorder.backend.repository;

import com.mto.madetoorder.backend.model.Kitchen;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface KitchenRepository extends MongoRepository<Kitchen, String> {
}


